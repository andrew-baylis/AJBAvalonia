// RadioGroup.axaml.cs
//  Andrew Baylis
//  Created: 11/1/2024

#region using

using System.ComponentModel;
using System.Windows.Input;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Interactivity;
using Avalonia.Layout;
using ReactiveUI;

#endregion

namespace AJBAvalonia;

public class RadioGroup : TemplatedControl
{
    #region Fields

    public static readonly DirectProperty<RadioGroup, int> ColumnsProperty =
        AvaloniaProperty.RegisterDirect<RadioGroup, int>(nameof(Columns), o => o.Columns, (o, v) => o.Columns = v);

    public static readonly DirectProperty<RadioGroup, bool> EvenSpacingProperty =
        AvaloniaProperty.RegisterDirect<RadioGroup, bool>(nameof(EvenSpacing), o => o.EvenSpacing, (o, v) => o.EvenSpacing = v);

    public static readonly DirectProperty<RadioGroup, int> HorizontalSpacingProperty =
        AvaloniaProperty.RegisterDirect<RadioGroup, int>(nameof(HorizontalSpacing), o => o.HorizontalSpacing, (o, v) => o.HorizontalSpacing = v);

    public static readonly DirectProperty<RadioGroup, string?> ItemListProperty =
        AvaloniaProperty.RegisterDirect<RadioGroup, string?>(nameof(ItemList), o => o.ItemList, (o, v) => o.ItemList = v);

    public static readonly DirectProperty<RadioGroup, Orientation> OrientationProperty =
        AvaloniaProperty.RegisterDirect<RadioGroup, Orientation>(nameof(Orientation), o => o.Orientation, (o, v) => o.Orientation = v);

    public static readonly DirectProperty<RadioGroup, int> RowsProperty = AvaloniaProperty.RegisterDirect<RadioGroup, int>(nameof(Rows), o => o.Rows, (o, v) => o.Rows = v);
    public static readonly StyledProperty<string?> SelectedMapValueProperty = AvaloniaProperty.Register<RadioGroup, string?>(nameof(SelectedMapValue));

    public static readonly StyledProperty<int> SelectedValueProperty = AvaloniaProperty.Register<RadioGroup, int>(nameof(SelectedValue));

    public static readonly DirectProperty<RadioGroup, int> VerticalSpacingProperty =
        AvaloniaProperty.RegisterDirect<RadioGroup, int>(nameof(VerticalSpacing), o => o.VerticalSpacing, (o, v) => o.VerticalSpacing = v);

    private readonly string _groupName;
    private readonly List<RadioButton> _list;
    private int _columns;

    private string[]? _enumMap;
    private bool _evenSpacing;
    private int _horizontalSpacing;
    private bool _inClick;
    private string? _itemList;
    private Orientation _orientation;

    private int _rows;
    private int _verticalSpacing;

    #endregion

    public RadioGroup()
    {
        _list = new List<RadioButton>();
        _groupName = Guid.NewGuid().ToString();
        RbClickCommand = ReactiveCommand.Create(RbClickExecute);
    }

    private UniformGrid? panel;
    protected override void OnApplyTemplate(TemplateAppliedEventArgs e)
    {
        base.OnApplyTemplate(e);
        panel = e.NameScope.Find<UniformGrid>("panel");
    }

    #region Properties

    [Category("Radio Group Props")]
    [Description("Number of Columns. If more than 1, Orientation determines how the columns are filled")]
    public int Columns
    {
        get => _columns;
        set
        {
            if (value < 0)
            {
                value = 0;
            }

            SetAndRaise(ColumnsProperty, ref _columns, value);
            RebuildChildren();
        }
    }

    [Category("Radio Group Props")]
    [Description("True = even space gap between items (sol long as columns = 1. False = items placed in a uniform grid")]
    public bool EvenSpacing
    {
        get => _evenSpacing;
        set
        {
            SetAndRaise(EvenSpacingProperty, ref _evenSpacing, value);
            RebuildChildren();
        }
    }

    [Category("Radio Group Props")]
    [Description("Horizontal margin for each radio button")]
    public int HorizontalSpacing
    {
        get => _horizontalSpacing;
        set
        {
            SetAndRaise(HorizontalSpacingProperty, ref _horizontalSpacing, value);
            RebuildChildren();
        }
    }

    [Category("Radio Group Props")]
    [Description("Holds comma delimited text for radiobuttons")]
    public string? ItemList
    {
        get => _itemList;
        set
        {
            SetAndRaise(ItemListProperty, ref _itemList, value);
            if (!string.IsNullOrEmpty(_itemList))
            {
                _enumMap = _itemList.Split(',', StringSplitOptions.TrimEntries);
                LoadContent(_enumMap);
            }
        }
    }

    [Category("Radio Group Props")]
    [Description("Whether the list fills vertically or horizontally")]
    public Orientation Orientation
    {
        get => _orientation;
        set
        {
            SetAndRaise(OrientationProperty, ref _orientation, value);
            RebuildChildren();
        }
    }

    public int Rows
    {
        get => _rows;
        set
        {
            if (value < 0)
            {
                value = 0;
            }

            SetAndRaise(RowsProperty, ref _rows, value);
            RebuildChildren();
        }
    }

    [Category("Radio Group Props")]
    [Description("If EnumMapping has been set, this returns the string at EnumMapping[index]")]
    public string? SelectedMapValue
    {
        get => GetValue(SelectedMapValueProperty);
        set => SetValue(SelectedMapValueProperty, value);
    }

    public int SelectedValue
    {
        get => GetValue(SelectedValueProperty);
        set => SetValue(SelectedValueProperty, value);
    }

    [Category("Radio Group Props")]
    [Description("Vertical margin for each radio button.")]
    public int VerticalSpacing
    {
        get => _verticalSpacing;
        set
        {
            if (value >= 0)
            {
                SetAndRaise(VerticalSpacingProperty, ref _verticalSpacing, value);
                RebuildChildren();
            }
        }
    }

    protected ICommand RbClickCommand { get; }

    #endregion

    #region Events

    public event EventHandler? SelectionChanged;

    #endregion

    #region Override Methods

    protected override void OnLoaded(RoutedEventArgs e)
    {
        base.OnLoaded(e);
        RebuildChildren();
    }

    protected override void OnPropertyChanged(AvaloniaPropertyChangedEventArgs change)
    {
        base.OnPropertyChanged(change);
        if (change.Property == SelectedMapValueProperty)
        {
            SetMapValue((string?) change.NewValue);
        }
        else if (change.Property == SelectedValueProperty && change.NewValue != null)
        {
            SetSelectedRadioButton((int) change.NewValue);
        }
    }

    #endregion

    #region Public Methods

    public string? GetItemAtValue(int value)
    {
        if (panel!=null && value >= 0 && value < panel.Children.Count)
        {
            var rb = (RadioButton) panel.Children[value];
            return (string?) rb.Content;
        }

        return null;
    }

    public T GetSelectedAsEnum<T>() where T : struct
    {
        if (typeof(T).IsEnum && _enumMap?.Length > 0)
        {
            if (SelectedValue >= 0 && SelectedValue < _enumMap.Length)
            {
                var s = _enumMap[SelectedValue];

                if (Enum.TryParse(s, true, out T result))
                {
                    return result;
                }
            }
        }

        return default;
    }

    public void LoadContent(List<string> list)
    {
        InternalMakeRadioButtons(list);
        RebuildChildren();
    }

    public void LoadContent(string[] list)
    {
        InternalMakeRadioButtons(list);
        RebuildChildren();
    }

    public void SetSelectedFromEnum<T>(T enumValue) where T : struct
    {
        if (typeof(T).IsEnum && _enumMap != null)
        {
            SetSelectedRadioButton(Array.IndexOf(_enumMap, enumValue.ToString())); //checks the index is within range
        }
    }

    #endregion

    #region Private Methods

    private string GetSelectedMapValue()
    {
        var i = GetSelectedRadioButton();

        if (_enumMap != null && i >= 0 && i < _enumMap.Length)
        {
            return _enumMap[i];
        }

        return string.Empty;
    }

    private int GetSelectedRadioButton()
    {
        var v = 0;
        if (panel != null)
        {
            var cnt = panel.Children.Count;

            while (v < cnt && !IsRBChecked(panel.Children[v]))
            {
                v++;
            }

            if (v >= cnt)
            {
                v = 0;
            }
        }

        return v;
    }

    private void InternalMakeRadioButtons(IEnumerable<string> list)
    {
        _list.Clear();
        panel?.Children.Clear();

        foreach (var s in list)
        {
            _list.Add(new RadioButton {Content = s, GroupName = _groupName, Command = RbClickCommand});
        }
    }

    private bool IsRBChecked(Control item)
    {
        if (item is RadioButton rb)
        {
            return rb.IsChecked == true;
        }

        return false;
    }

    private void RbClickExecute()
    {
        _inClick = true;

        try
        {
            SelectedValue = GetSelectedRadioButton();
            SelectedMapValue = GetSelectedMapValue();
            SelectionChanged?.Invoke(this, EventArgs.Empty);
        }
        finally
        {
            _inClick = false;
        }
    }

    private void RebuildChildren()
    {
        if (panel != null)
        {
            panel.Children.Clear();
            var numItems = _list.Count;
            if (numItems > 0)
            {
                var cMax = 1;
                var rMax = numItems;
                if (Columns == 0)
                {
                    if (Rows > 0)
                    {
                        var (quot, rem) = Math.DivRem(numItems, Rows);
                        cMax = quot + (rem > 0 ? 1 : 0);
                        rMax = Rows;
                    }
                }
                else
                {
                    var (quot, rem) = Math.DivRem(numItems, Columns);
                    rMax = quot + (rem > 0 ? 1 : 0);
                    cMax = Columns;
                }

                panel.Columns = cMax;
                panel.Rows = rMax;
                switch (Orientation)
                {
                    case Orientation.Horizontal:
                    {
                        var c = 0;
                        var r = 0;
                        for (var i = 0; i < _list.Count; i++)
                        {
                            var rb = _list[i];
                            Grid.SetColumn(rb, c);
                            Grid.SetRow(rb, r);
                            c++;
                            if (c >= cMax)
                            {
                                c = 0;
                                r++;
                            }
                        }
                    }
                        break;

                    case Orientation.Vertical:
                    {
                        var c = 0;
                        var r = 0;
                        for (var i = 0; i < _list.Count; i++)
                        {
                            var rb = _list[i];
                            Grid.SetColumn(rb, c);
                            Grid.SetRow(rb, r);
                            r++;
                            if (r >= rMax)
                            {
                                r = 0;
                                c++;
                            }
                        }
                    }
                        break;
                }

                foreach (var rb in _list)
                {
                    panel.Children.Add(rb);
                }

                SelectedValue = 0;
                SetSelectedRadioButton(0);
            }
        }
    }

    private void SetMapValue(string? value)
    {
        if (_enumMap != null && !string.IsNullOrEmpty(value))
        {
            SetSelectedRadioButton(Array.IndexOf(_enumMap, value));
        }
    }

    private void SetSelectedRadioButton(int value)
    {
        if (panel!=null && !_inClick && value >= 0 && value < panel.Children.Count)
        {
            if (panel.Children[value] is RadioButton rb)
            {
                rb.IsChecked = true;
            }
        }
    }

    #endregion
}